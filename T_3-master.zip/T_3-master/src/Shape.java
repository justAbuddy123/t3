public abstract class Shape {
    abstract double P();
    abstract double S();
}
